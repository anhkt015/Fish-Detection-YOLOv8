# Fish-Detection-YOLOv8
A YOLOv8-based fish detection project using custom dataset .
